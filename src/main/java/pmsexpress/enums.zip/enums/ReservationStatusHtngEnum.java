package pmsexpress.enums;

public enum ReservationStatusHtngEnum {
  PRE_CONFIRMED,
  RESERVED,
  NO_SHOW,
  PRE_CHECKED_IN,
  IN_HOUSE,
  CHECKED_OUT,
  CANCELED;
}
