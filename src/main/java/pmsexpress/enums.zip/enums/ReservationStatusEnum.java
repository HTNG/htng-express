package pmsexpress.enums;

public enum ReservationStatusEnum {
  RESERVED;
}
