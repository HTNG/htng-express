package pmsexpress.enums;

public enum LoyaltyLevelEnum {
  GOLD,
  SILVER,
  BRONZE;

}
