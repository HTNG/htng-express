package pmsexpress.enums;

public enum HousekeepingOccupancyStatusEnum {

}
