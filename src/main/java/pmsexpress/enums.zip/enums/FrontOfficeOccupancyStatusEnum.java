package pmsexpress.enums;

public enum FrontOfficeOccupancyStatusEnum {

}
