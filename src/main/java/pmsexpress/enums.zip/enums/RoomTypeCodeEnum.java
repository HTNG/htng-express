package pmsexpress.enums;

public enum RoomTypeCodeEnum {
  KOVC;

}
