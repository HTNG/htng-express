package pmsexpress.enums;

public enum EmailTypeEnum {
  // check on these... I just made these up
  PERSONAL,
  BUSINESS,
  AGENCY;
}
