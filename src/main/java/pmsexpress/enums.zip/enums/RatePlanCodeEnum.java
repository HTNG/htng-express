package pmsexpress.enums;

public enum RatePlanCodeEnum {
  BAR;

}
