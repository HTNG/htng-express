package pmsexpress.enums;

public enum InventoryStatusEnum {

}
