package pmsexpress.enums;

public enum LoyaltyProgramTypeEnum {
  BA;
}
