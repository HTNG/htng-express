package pmsexpress.enums;

public enum VipCodeEnum {
  VIP1;

}
